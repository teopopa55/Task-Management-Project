package DataModel;

import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;

public final class ComplexTask extends Task implements Serializable
{
    private static final long serialVersionUID = 1L;
    private List<Task> tasks =new ArrayList<>();

    public ComplexTask(int idTask, String statusTask, List<Task> tasks) {
        super(idTask, statusTask);
        this.tasks=tasks;
    }

    public List<Task> getTasks() {
        return tasks;
    }

    public void setTasks(List<Task> tasks) {
        this.tasks = tasks;
    }

    public void addTask(Task task)
    {
        tasks.add(task);
    }

    public void deleteTask(Task task)
    {
        tasks.remove(task);
    }

    @Override
    public int estimateDuration()
    {
        int duration=0;
        for(Task t: tasks)
        {
            duration+=t.estimateDuration();
        }
        return duration;
    }

}
