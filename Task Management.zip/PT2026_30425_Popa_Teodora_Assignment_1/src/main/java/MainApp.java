import BusinessLogic.TasksManagement;
import DataAccess.FileHandler;
import DataModel.ComplexTask;
import DataModel.Employee;
import DataModel.SimpleTask;
import DataModel.Task;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainApp
{
    //transient=> not included in file - serializable

    public static void main(String[] args)
    {
        List<Task> tasks=new ArrayList<>();
        Map<Employee, List<Task> > employees= new HashMap<>();

        //1.ADD TASK
        Task t100=new SimpleTask(100, "Completed", 8, 16);
        Task t101=new SimpleTask(101, "Uncompleted", 9, 17);
        Task t102=new SimpleTask(102, "Completed", 8, 16);
        Task t103=new SimpleTask(103, "Uncompleted", 10, 18);
        Task t104=new SimpleTask(104, "Completed", 8, 16);
        Task t108=new SimpleTask(108, "Completed", 7, 15);
        Task t109=new SimpleTask(109, "Completed", 7, 19);
        Task t110=new SimpleTask(110, "Uncompleted", 8, 15 );
        tasks.add(t104);
        tasks.add(t108);
        tasks.add(t109);
        tasks.add(t110);

        List<Task> tf5=new ArrayList<>();
        tf5.add(t100);
        tf5.add(t101);
        Task t105=new ComplexTask(105, "Uncompleted",tf5);
        tasks.add(t105);

        List<Task> tf6=new ArrayList<>();
        tf6.add(t102);
        tf6.add(t103);
        Task t106=new ComplexTask(106, "Completed", tf6);
        tasks.add(t106);


        TasksManagement tm= new TasksManagement(employees, tasks);

        //1.ADD EMPLOYEE
        Employee em= new Employee(500, "Mihaela");
        Employee ema=new Employee(501, "Maia");
        Employee el= new Employee(502, "Liliana");
        Employee ed=new Employee(503, "Diana");
        tm.addEmployee(em);
        tm.addEmployee(ema);
        tm.addEmployee(el);
        tm.addEmployee(ed);

        //1.ASSIGN TASK TO EMPLOYEE
        tm.assignTaskToEmployee(500, t105);
        tm.assignTaskToEmployee(500, t108);
        tm.assignTaskToEmployee(500, t109);
        tm.assignTaskToEmployee(500, t110);
        tm.assignTaskToEmployee(503, t106);
        tm.assignTaskToEmployee(502, t104);

        //2.VIEW EMPLOYEES
        tm.viewEmployeesAndTasks();
        System.out.println("\n");

        //3.MODIFY TASK STATUS
        tm.modifyTaskStatus(502, 104);
        tm.viewEmployeesAndTasks();
        System.out.println("\n");

        //4.VIEW STATISTICS
        tm.viewStatistics();
        System.out.println("\n");




    }

}
