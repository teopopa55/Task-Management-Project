package BusinessLogic;

import DataAccess.FileHandler;
import DataModel.Employee;
import DataModel.Task;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TasksManagement  implements Serializable
{
    private Map<Employee, List<Task> > employees= new HashMap<>();
    private List<Task> tasks=new ArrayList<>();

    public TasksManagement(Map<Employee, List<Task>> employees, List<Task> tasks) {
        this.employees = employees;
        this.tasks = tasks;
    }

    public Map<Employee, List<Task>> getMap() {
        return employees;
    }

    public void setEmployees(Map<Employee, List<Task>> employees) {
        this.employees = employees;
    }

    public List<Task> getTasks() {
        return tasks;
    }

    public void setTasks(List<Task> tasks) {
        this.tasks = tasks;
    }

    public int calculateEmployeeWorkDuration(int idEmployee)
    {
        int hoursWorked=0;

        for(Employee e:employees.keySet())
        {
            if(e.getIdEmployee()==idEmployee)
            {
               for(Task t:employees.get(e))
               {

                   hoursWorked+=t.estimateDuration();
               }
            }
        }


        return hoursWorked;
    }


    //1. Add employees, add task, assign task to employee

    public void addEmployee(Employee e)
    {
        if(!employees.containsKey(e))
        {
            employees.put(e, new ArrayList<>());
        }
    }

    public void addTask(Task t)
    {
        if(!tasks.contains(t))
               tasks.add(t);

    }

    public void assignTaskToEmployee(int idEmployee, Task task)
    {

        for(Employee e:employees.keySet())
        {
            if(e.getIdEmployee()==idEmployee)
            {
                employees.get(e).add(task);
                tasks.remove(task);
                break;
            }
        }
    }

    //2.View employees and their tasks
    public void viewEmployeesAndTasks()
    {
        System.out.println("\nThe employees and their tasks are: ");
        int i=1;
        for(Employee e: employees.keySet())
        {
            System.out.println(i+ ".Employee: "+e.getName());
            for(Task t: employees.get(e))
            {
                System.out.println("Task: "+t.getIdTask()+ " | Estimated duration: "+t.estimateDuration()
                        + " | Status: "+t.getStatusTask());
            }
            i++;
        }
    }

    //3.Modify the status of a task assigned to an employee
    public void modifyTaskStatus(int idEmployee, int idTask)
    {

        for(Employee e:employees.keySet())
        {
            if (e.getIdEmployee() == idEmployee)
            {
                for(Task t:employees.get(e))
                {
                    if(t.getIdTask()==idTask)
                    {
                        if(t.getStatusTask().equals("Completed"))
                            t.setStatusTask("Uncompleted");
                        else t.setStatusTask("Completed");
                    }
                }
            }
        }

    }

    //4.View statistics
    public void viewStatistics() {
        System.out.println("1. People who worked over 40 hours: ");
        Utility utility = new Utility();
        utility.filterEmployees(this);
        System.out.println("2.Number of Completed and Uncompleted tasks per employee: ");
        Map<String, Map<String, Integer>> statusMap = utility.computeTasksStatus(this);
        for (String employeeName : statusMap.keySet())
        {
            System.out.println("Employee: "+employeeName);
            Map<String, Integer>tasks=statusMap.get(employeeName);
            System.out.println("Completed: "+ tasks.get("Completed")+ " | Uncompleted: "+tasks.get("Uncompleted"));
        }
    }

}
