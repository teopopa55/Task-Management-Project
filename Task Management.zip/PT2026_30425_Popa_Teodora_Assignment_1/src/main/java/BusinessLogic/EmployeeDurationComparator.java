package BusinessLogic;

import DataModel.Employee;

import java.util.Comparator;

public class EmployeeDurationComparator implements Comparator<Employee>
{
    private TasksManagement tm;

    public EmployeeDurationComparator(TasksManagement tm)
    {
        this.tm=tm;
    }

    @Override
    public int compare(Employee e1, Employee e2)
    {
        int d1=tm.calculateEmployeeWorkDuration(e1.getIdEmployee());
        int d2=tm.calculateEmployeeWorkDuration(e2.getIdEmployee());
        if(d1<d2) return -1;
        if(d1>d2) return 1;
        return 0;
    }

}
