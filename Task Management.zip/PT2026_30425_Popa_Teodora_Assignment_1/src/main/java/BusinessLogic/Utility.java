package BusinessLogic;

import DataModel.Employee;
import DataModel.Task;

import java.io.Serializable;
import java.util.*;

public class Utility  implements Serializable
{

    public void filterEmployees(TasksManagement tm)
    {

        Map<Employee, Integer> filtered=new HashMap<>();

        //filter the employees which worked >=40 and put them in a separate map
        for(Employee e: tm.getMap().keySet())
        {
            int duration= tm.calculateEmployeeWorkDuration(e.getIdEmployee());
            if(duration>=40)
                filtered.put(e,duration);
        }

        List<Employee> result= new ArrayList<>(filtered.keySet());

        //sort in ascending order
        Collections.sort(result, new EmployeeDurationComparator(tm));

        for(Employee e :result)
            System.out.println(e.getName());

    }

    public List<Employee> filterEmployeesStatistics(TasksManagement tm)
    {

        Map<Employee, Integer> filtered=new HashMap<>();

        //filter the employees which worked >=40 and put them in a separate map
        for(Employee e: tm.getMap().keySet())
        {
            int duration= tm.calculateEmployeeWorkDuration(e.getIdEmployee());
            if(duration>=40)
                filtered.put(e,duration);
        }

        List<Employee> result= new ArrayList<>(filtered.keySet());

        //sort in ascending order
        Collections.sort(result, new EmployeeDurationComparator(tm));

        return result;
    }

    public Map<String,Map<String, Integer>> computeTasksStatus(TasksManagement tm)
    {
        Map<String,Map<String, Integer>> result= new HashMap<>();

        for(Employee e: tm.getMap().keySet())
        {
            int completed=0, uncompleted=0;
            for(Task t: tm.getMap().get(e))
            {
                if(t.getStatusTask().equals("Completed")) completed++;
                else uncompleted++;
            }
            Map<String, Integer> statusMap=new HashMap<>();
            statusMap.put("Completed", completed);
            statusMap.put("Uncompleted", uncompleted);

            result.put(e.getName(),statusMap);
        }


        return result;
    }

}
