package GraphicalUserInterface;

import BusinessLogic.TasksManagement;
import DataAccess.FileHandler;
import DataModel.ComplexTask;
import DataModel.Employee;
import DataModel.Task;

import javax.swing.*;
import java.awt.*;
import java.util.Map;
import java.util.List;

public class ChangeTaskStatusGUI
{
    public static void showModifyTaskStatus(TasksManagement tm, JFrame previousFrame, FileHandler fileHandler) {

        JFrame frame= new JFrame("Modify Task Status");
        frame.setSize(400,200);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new GridLayout(0,2,10,10));

        JLabel idLabel=new JLabel("Employee ID: ");
        JTextField idField = new JTextField();
        JLabel taskLabel=new JLabel("Task ID: ");
        JTextField taskField=new JTextField();
        JButton modifyButton=new JButton("Toggle Status");

        frame.add(idLabel);
        frame.add(idField);
        frame.add(taskLabel);
        frame.add(taskField);
        frame.add(new JLabel()); //so that it looks better
        frame.add(modifyButton);
        JButton backButton=new JButton("Back");
        backButton.setPreferredSize(new Dimension(80,25));
        backButton.addActionListener(e->{
            frame.dispose();
            previousFrame.setVisible(true);
        });
        frame.add(backButton);

        modifyButton.addActionListener(e-> {
              try{
                  int empId=Integer.parseInt(idField.getText());
                  int taskId=Integer.parseInt(taskField.getText());

                  boolean valid=false;
                  for(Map.Entry<Employee,List<Task>> entry : tm.getMap().entrySet())
                  {
                      if(entry.getKey().getIdEmployee()==empId)
                      {
                          for(Task t:entry.getValue())
                          {
                              if(t.getIdTask()==taskId)
                              {
                                  valid=true;
                                  break;
                              }
                          }
                          break;
                      }
                  }
                  if(!valid)
                  {
                      JOptionPane.showMessageDialog(frame, "Employee/Task/Association between this employee and this task is INVALID!");
                      return;
                  }

                  tm.modifyTaskStatus(empId,taskId);

                  try {
                      fileHandler.saveData(tm);
                  }catch(Exception exception)
                  {
                      exception.printStackTrace();
                  }

                  JOptionPane.showMessageDialog(frame,"Task Status updated!");
                  frame.dispose();
              }catch(NumberFormatException ex)
              {
                  JOptionPane.showMessageDialog(frame, "Invalid ID input!");
              }
        });


        frame.setVisible(true);

    }
}
