package GraphicalUserInterface;

import BusinessLogic.TasksManagement;
import DataAccess.FileHandler;
import DataModel.Employee;
import DataModel.SimpleTask;
import DataModel.Task;

import javax.swing.*;
import java.awt.*;
import java.util.concurrent.Flow;

public class AssignTaskToEmployeeGUI
{
    public static void showAssignTask(TasksManagement tm, JFrame previousFrame, FileHandler fileHandler) {

        JFrame frame= new JFrame("Assign Task to Employee");
        frame.setSize(400,200);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new GridLayout(0,2,10,10));

        JLabel empIDLabel=new JLabel("Employee ID: ");
        frame.add(empIDLabel);
        DefaultListModel<Employee> emplistModel= new DefaultListModel<>();
        for(Employee e:tm.getMap().keySet())
        {
                emplistModel.addElement((Employee) e);
        }
        JList<Employee> empList= new JList<>(emplistModel);
        empList.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        JScrollPane scrollPaneemp= new JScrollPane(empList);
         frame.add(scrollPaneemp);

        JLabel taskIDLabel=new JLabel("Task ID: ");
        frame.add(taskIDLabel);
        DefaultListModel<Task> listModel= new DefaultListModel<>();
        for(Task t:tm.getTasks())
        {
            listModel.addElement((Task) t);
        }
        JList<Task> taskList= new JList<>(listModel);
        taskList.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        JScrollPane scrollPanetk= new JScrollPane(taskList);
        frame.add(scrollPanetk);

        JButton assignButton=new JButton("Assign Task");

        frame.add(new JLabel()); //so that it looks better
        frame.add(assignButton);

        JButton backButton=new JButton("Back");
        backButton.setPreferredSize(new Dimension(80,25));
        backButton.addActionListener(e->{
            frame.dispose();
            previousFrame.setVisible(true);
        });
        frame.add(backButton);

        assignButton.addActionListener(e->{
                Employee selectedemp=empList.getSelectedValue();
                Task selectedtask=taskList.getSelectedValue();
                if(selectedemp==null)
                {
                    JOptionPane.showMessageDialog(frame, "Please choose an employee!");
                    return;
                }
                if(selectedtask==null)
                {
                    JOptionPane.showMessageDialog(frame,"Please choose a task!");
                    return;
                }
                tm.assignTaskToEmployee(selectedemp.getIdEmployee(),selectedtask);
            try {
                fileHandler.saveData(tm);
            }catch(Exception exception)
            {
                exception.printStackTrace();
            }

            JOptionPane.showMessageDialog(frame, "Task: "+selectedtask.getIdTask()+
                                             " assigned to Employee: "+selectedemp.getIdEmployee());

        });

               frame.setVisible(true);

    }
}
