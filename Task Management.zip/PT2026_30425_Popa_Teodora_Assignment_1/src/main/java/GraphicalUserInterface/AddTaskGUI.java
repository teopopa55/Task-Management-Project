package GraphicalUserInterface;

import BusinessLogic.TasksManagement;
import DataAccess.FileHandler;
import DataModel.Employee;
import DataModel.SimpleTask;
import DataModel.Task;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class AddTaskGUI
{

    public static void showAddTask(TasksManagement tm, JFrame previousFrame, FileHandler fileHandler) {

        JFrame frame= new JFrame("Add Task");
        frame.setSize(400,300);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new GridLayout(0,2,10,10));

        JLabel idLabel=new JLabel("Simple Task ID: ");
        JTextField idField = new JTextField();
        JLabel nameLabel=new JLabel("Simple Task Status: ");
        JCheckBox completed=new JCheckBox("Completed");
        JCheckBox uncompleted=new JCheckBox("Uncompleted");
        JLabel startLabel = new JLabel("Start Hour: ");
        JTextField startField = new JTextField();
        JLabel endLabel = new JLabel("End Hour: ");
        JTextField endField = new JTextField();
        frame.add(idLabel);
        frame.add(idField);
        frame.add(startLabel);
        frame.add(startField);
        frame.add(endLabel);
        frame.add(endField);
        frame.add(nameLabel);
        ButtonGroup statusGroup=new ButtonGroup();
        statusGroup.add(completed);
        statusGroup.add(uncompleted);
        JPanel statusPanel=new JPanel();
        statusPanel.add(completed);
        statusPanel.add(uncompleted);
        frame.add(statusPanel);
        JButton addButton=new JButton("Add Simple Task");

        frame.add(new JLabel()); //so that it looks better
        frame.add(addButton);

        JButton backButton=new JButton("Back");
        backButton.setPreferredSize(new Dimension(40,25));
        backButton.addActionListener(e->{
            frame.dispose();
            previousFrame.setVisible(true);
        });
        frame.add(backButton);

        addButton.addActionListener(e->{
            try{
                int id=Integer.parseInt(idField.getText());
                int start=Integer.parseInt(startField.getText());
                int end=Integer.parseInt(endField.getText());

                if(start>end)
                {
                    JOptionPane.showMessageDialog(frame, "End time MUST be GREATER than Start time!");
                    return;
                }
                String status;
                if(completed.isSelected()) status="Completed";
                 else status="Uncompleted";

                boolean idExists=false;

                for(List<Task> taskList: tm.getMap().values())
                {
                    for(Task t:taskList)
                    {
                        if(t.getIdTask()==id)
                        {
                            idExists=true;
                            break;
                        }
                    }
                    if(idExists)break;
                }
                if(idExists)
                {
                    JOptionPane.showMessageDialog(frame,"Task ID already exists!");
                    return;
                }

                Task task= new SimpleTask(id,status,start,end);
                tm.addTask(task);

                try {
                    fileHandler.saveData(tm);
                }catch(Exception exception)
                {
                    exception.printStackTrace();
                }

                JOptionPane.showMessageDialog(frame, "Simple Task added!");
                frame.dispose();
            }catch(NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(frame,"Invalid input!");
            }
        });

        frame.setVisible(true);

    }
}
