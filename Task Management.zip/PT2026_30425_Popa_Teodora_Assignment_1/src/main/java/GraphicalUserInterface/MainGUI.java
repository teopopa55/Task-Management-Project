package GraphicalUserInterface;

import BusinessLogic.TasksManagement;
import DataAccess.FileHandler;
import DataModel.ComplexTask;
import DataModel.Employee;
import DataModel.SimpleTask;
import DataModel.Task;
import DataAccess.FileHandler;
import javax.swing.*;
import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.BoxLayout;
import javax.swing.Box;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Insets;
import java.awt.Dimension;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;



public class MainGUI {
    // static so it can be called directly from main without creating a MainGUI instance.
    public static TasksManagement LoadHardcodedData()
    {
        List<Task> tasks=new ArrayList<>();
        Map<Employee, List<Task> > employees= new HashMap<>();

        Task[] simple={new SimpleTask(100, "Completed", 8, 16),
                new SimpleTask(101, "Uncompleted", 9, 17),
                new SimpleTask(102, "Completed", 8, 16),
                new SimpleTask(103, "Uncompleted", 10, 18),
                new SimpleTask(104, "Completed", 8, 16),
                new SimpleTask(120, "Completed", 9, 17),
                new SimpleTask(121, "Uncompleted", 10, 18),
                new SimpleTask(122, "Uncompleted", 8, 16)};

        for(int i=0;i<8;i++)
            tasks.add(simple[i]);

        List<Task> complexTasks1=new ArrayList<>();
        complexTasks1.add(new SimpleTask(105, "Uncompleted", 8, 16));
        complexTasks1.add(new SimpleTask(106, "Uncompleted", 9, 18));
        complexTasks1.add(new SimpleTask(107, "Completed", 10, 16));
        complexTasks1.add(new SimpleTask(108, "Uncompleted", 10, 16));
        Task ct1=new ComplexTask(109, "Completed", complexTasks1);
        tasks.add(ct1);

        List<Task> complexTasks2=new ArrayList<>();
        complexTasks2.add(new SimpleTask(110, "Completed", 9, 17));
        complexTasks2.add(new SimpleTask(111, "Completed", 8,16 ));
        complexTasks2.add(new SimpleTask(112, "Uncompleted", 8, 19));
        complexTasks2.add(new SimpleTask(113, "Completed", 8, 18));
        Task ct2=new ComplexTask(114, "Uncompleted", complexTasks2);
        tasks.add(ct2);

        List<Task> complexTasks3=new ArrayList<>();
        complexTasks3.add(new SimpleTask(115, "Completed", 10, 17));
        complexTasks3.add(new SimpleTask(116, "Completed", 10,16 ));
        complexTasks3.add(new SimpleTask(117, "Uncompleted", 10, 19));
        complexTasks3.add(new SimpleTask(118, "Uncompleted", 10, 18));
        Task ct3=new ComplexTask(119, "Uncompleted", complexTasks3);
        tasks.add(ct3);

        TasksManagement tm=new TasksManagement(employees, tasks);

        tm.addEmployee(new Employee(500, "Mihaela"));
        tm.addEmployee(new Employee(501, "Luca"));
        tm.addEmployee(new Employee(502, "Anastasia"));
        tm.addEmployee(new Employee(503, "Larisa"));
        tm.addEmployee(new Employee(504, "Dorel"));
        tm.addEmployee(new Employee(505, "Mircea"));
        tm.addEmployee(new Employee(506, "Diana"));
        tm.addEmployee(new Employee(507, "Liana"));
        tm.addEmployee(new Employee(508, "Gratiela"));
        tm.addEmployee(new Employee(509, "Robert"));
        tm.addEmployee(new Employee(510, "Antoanela"));
        tm.addEmployee(new Employee(511, "Mirela"));
        tm.addEmployee(new Employee(512, "Andrei"));
        tm.addEmployee(new Employee(513, "Alexandru"));
        tm.addEmployee(new Employee(514, "Darius"));
        tm.addEmployee(new Employee(515, "Sebastian"));

        tm.assignTaskToEmployee(500, simple[0]);
        tm.assignTaskToEmployee(500, simple[1]);
        tm.assignTaskToEmployee(500, simple[2]);
        tm.assignTaskToEmployee(500, ct1);
        tm.assignTaskToEmployee(503, simple[3]);
        tm.assignTaskToEmployee(502, ct3);
        tm.assignTaskToEmployee(501, simple[4]);
        tm.assignTaskToEmployee(503, ct2);
        return tm;
    }
    public static void main(String[]args)
    {

        FileHandler fileHandler=new FileHandler();
        TasksManagement tm;

        try {
            tm = fileHandler.loadData();

            if (tm == null) {
                System.out.println("No save file found. Loading hardcoded data...");
                tm = LoadHardcodedData();
                fileHandler.saveData(tm);
            }
        } catch (Exception e) {
            System.out.println("Error loading file, falling back to defaults.");
            tm = LoadHardcodedData();
        }

        //final because it is down accessed inside an anonymous inner class (WindowAdapter),
        final TasksManagement finalTm = tm;

        //Frame for main menu
        JFrame frame=new JFrame("Main Menu");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                try {
                    System.out.println("Saving Data...");
                    fileHandler.saveData(finalTm); //for ensuring the saving
                    //WindowAdapter inner class is not allowed to capture a variable whose value can change=>need final
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(frame, "Error saving data!");
                }
                System.exit(0);
            }
        });
        frame.setSize(800,400);
        frame.setLocationRelativeTo(null);

        //Panel with buttons for each functionality
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3,2,10,10)); //screen divided in 2 columns
                                                                         //3 rows
        panel.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));//padding


        //Creating and 6 buttons
        String[] titles={"ADD EMPLOYEE", "ADD TASK", "ASSIGN TASK TO EMPLOYEE",
                "VIEW EMPLOYEES AND TASKS", "MODIFY TASK STATUS", "VIEW STATISTICS"};
        JButton[] buttons= new JButton[6];

        for(int i=0;i<6;i++)
        {
            buttons[i]=new JButton(titles[i]);
            buttons[i].setFont(new Font("Arial", Font.BOLD,20));
            panel.add(buttons[i]);
        }

        ArrayList<Employee>  list=null;

        buttons[0].addActionListener(e->AddEmployeesGUI.showAddEmployee(finalTm,frame,fileHandler));
        buttons[1].addActionListener(e->ChooseTaskType.showChooseTask(finalTm,frame, fileHandler));
        buttons[2].addActionListener(e->AssignTaskToEmployeeGUI.showAssignTask(finalTm,frame,fileHandler));
        buttons[3].addActionListener(e->ViewEmployeesAndTasksGUI.showTable(list,finalTm,frame));
        buttons[4].addActionListener(e->ChangeTaskStatusGUI.showModifyTaskStatus(finalTm,frame,fileHandler));
        buttons[5].addActionListener(e->ViewStatisticsGUI.showStatistics(finalTm,frame));

        frame.add(panel);
        frame.setVisible(true);



    }
}
