package GraphicalUserInterface;

import BusinessLogic.TasksManagement;
import DataAccess.FileHandler;
import DataModel.ComplexTask;
import DataModel.Task;

import DataModel.SimpleTask;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class AddComplexTaskGUI {
    public static void showAddComplexTask(TasksManagement tm, JFrame previousFrame, FileHandler fileHandler)
    {
        JFrame frame= new JFrame("Add Task");
        frame.setSize(400,300);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new GridLayout(0,2,10,10));

        JLabel idLabel=new JLabel("Complex Task ID: ");
        JTextField idField = new JTextField();
        JLabel nameLabel=new JLabel("Complex Task Status: ");
        JCheckBox completed=new JCheckBox("Completed");
        JCheckBox uncompleted=new JCheckBox("Uncompleted");
        frame.add(idLabel);
        frame.add(idField);
        frame.add(nameLabel);
        ButtonGroup statusGroup=new ButtonGroup();
        statusGroup.add(completed);
        statusGroup.add(uncompleted);
        JPanel statusPanel=new JPanel();
        statusPanel.add(completed);
        statusPanel.add(uncompleted);
        frame.add(statusPanel);

        DefaultListModel<Task> listModel= new DefaultListModel<>();
        for(Task t:tm.getTasks())
        {
                listModel.addElement((Task) t);
        }
        JList<Task> taskList= new JList<>(listModel);
        taskList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        JScrollPane scrollPane= new JScrollPane(taskList);

       frame.add(new JLabel("Select Simple Tasks: "));
       frame.add(scrollPane);
       JButton addButton= new JButton("Add Complex Task");
       JButton backButton= new JButton("Back");

        backButton.setPreferredSize(new Dimension(40,25));
        backButton.addActionListener(e->{
            frame.dispose();
           previousFrame.setVisible(true);
        });
        frame.add(backButton);

        addButton.addActionListener(e->{
            try{
                int id=Integer.parseInt(idField.getText());
                String status;
                if(completed.isSelected())status="Completed";
                else status="Uncompleted";
                java.util.List<Task>selected=taskList.getSelectedValuesList();
                java.util.List<Task> selectedTasks= new java.util.ArrayList<>();
                for(Task t: selected)
                {
                    selectedTasks.add(t);
                    tm.getTasks().remove(t);
                }
                boolean idExists=false;
                for(List<Task> taskList1: tm.getMap().values())
                {
                    for(Task t:taskList1)
                    {
                        if(t.getIdTask()==id)
                        {
                            idExists=true;
                            break;
                        }
                    }
                    if(idExists)break;
                }
                if(idExists)
                {
                    JOptionPane.showMessageDialog(frame,"Task ID already exists!");
                    return;
                }
                Task task= new ComplexTask(id,status,selectedTasks);
                tm.addTask(task);

                try {
                    fileHandler.saveData(tm);
                }catch(Exception exception)
                {
                    exception.printStackTrace();
                }

                JOptionPane.showMessageDialog(frame, "Complex Task added!");
                frame.dispose();
            }catch(NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame,"Invalid input!");
            }
        });


       frame.add(addButton);
        frame.setVisible(true);

    }
}
