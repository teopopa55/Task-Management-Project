package GraphicalUserInterface;
import BusinessLogic.TasksManagement;
import DataAccess.FileHandler;
import DataModel.Employee;

import javax.swing.*;
import java.awt.*;

public class AddEmployeesGUI
{
    public static void showAddEmployee(TasksManagement tm, JFrame previousFrame, FileHandler fileHandler) {

        JFrame frame= new JFrame("Add Employee");
        frame.setSize(400,200);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new GridLayout(0,2,10,10));

        JLabel idLabel=new JLabel("Employee ID: ");
        JTextField idField = new JTextField();
        JLabel nameLabel=new JLabel("Employee Name: ");
        JTextField nameField=new JTextField();
        JButton addButton=new JButton("Add Employee");

        frame.add(idLabel);
        frame.add(idField);
        frame.add(nameLabel);
        frame.add(nameField);
        frame.add(new JLabel()); //so that it looks better
        frame.add(addButton);

        JButton backButton=new JButton("Back");
        backButton.setPreferredSize(new Dimension(40,25));
        backButton.addActionListener(e->{
            frame.dispose();
            previousFrame.setVisible(true);
        });
        frame.add(backButton);

        addButton.addActionListener(e->{
            try{
                int id=Integer.parseInt(idField.getText());
                String name=nameField.getText();

                if(!name.matches("[a-zA-Z]+"))
                {
                    JOptionPane.showMessageDialog(frame, "Name must contain ONLY letters!");
                    return;
                }

                boolean idExists=false;
                for(Employee emp: tm.getMap().keySet())
                {
                    if(emp.getIdEmployee()==id)
                    {
                        idExists=true;
                        break;
                    }
                }
                if(idExists)
                {
                    JOptionPane.showMessageDialog(frame,"This Employee ID already exists!");
                    return;
                }

                Employee emp = new Employee(id,name);
                tm.addEmployee(emp);

                try {
                    fileHandler.saveData(tm);
                }catch(Exception exception)
                {
                    exception.printStackTrace();
                }

                JOptionPane.showMessageDialog(frame, "Employee added!");
                frame.dispose();
            }catch(NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(frame,"Invalid ID!");
            }
        });


       frame.setVisible(true);

    }

}
