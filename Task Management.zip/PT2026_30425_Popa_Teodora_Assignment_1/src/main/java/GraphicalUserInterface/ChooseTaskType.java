package GraphicalUserInterface;

import BusinessLogic.TasksManagement;
import DataAccess.FileHandler;

import javax.swing.*;
import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.BoxLayout;
import javax.swing.Box;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Insets;
import java.awt.Dimension;

public class ChooseTaskType {

    public static void showChooseTask(TasksManagement tm, JFrame previousFrame, FileHandler fileHandler)
    {
        JFrame frame = new JFrame("Task Type Selection");
        frame.setSize(400, 300);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(0,2,10,10));
        panel.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));

        JButton[] buttons= new JButton[2];
        buttons[0]= new JButton("ADD SIMPLE TASK");
        buttons[0].setFont(new Font("Arial", Font.BOLD,20));
        panel.add(buttons[0]);
        buttons[1]= new JButton("ADD COMPLEX TASK");
        buttons[1].setFont(new Font("Arial", Font.BOLD,20));
        panel.add(buttons[1]);

        buttons[0].addActionListener(e->AddTaskGUI.showAddTask(tm, frame, fileHandler));
        buttons[1].addActionListener(e->AddComplexTaskGUI.showAddComplexTask(tm, frame, fileHandler));

        JButton backButton=new JButton("Back");
        backButton.setPreferredSize(new Dimension(80,25));
        backButton.addActionListener(e->{
            frame.dispose();
            previousFrame.setVisible(true);
        });

        JPanel topPanel=new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.add(backButton);
        frame.add(topPanel,BorderLayout.NORTH);


        frame.add(panel, BorderLayout.CENTER);
        frame.setVisible(true);
    }
}
