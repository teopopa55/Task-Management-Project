package GraphicalUserInterface;
import BusinessLogic.TasksManagement;
import BusinessLogic.Utility;
import DataAccess.FileHandler;
import DataModel.Employee;

import java.util.HashMap;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Map;

public class ViewStatisticsGUI
{
        public static void showStatistics (TasksManagement tm, JFrame previousFrame)
        {

            JFrame frame= new JFrame("Statistics");
            frame.setSize(500,800);
            frame.setLocationRelativeTo(null);
            frame.setLayout(new BorderLayout());

            JButton backButton=new JButton("Back");
            backButton.setPreferredSize(new Dimension(80,25));
            backButton.addActionListener(e->{
                frame.dispose();
                previousFrame.setVisible(true);
            });
            JPanel topPanel=new JPanel(new FlowLayout(FlowLayout.LEFT));
            topPanel.add(backButton);
            frame.add(topPanel,BorderLayout.NORTH);

            JPanel tablesPanel=new JPanel(new GridLayout(2,1));

            Utility utility= new Utility();

            //Table for work duration>40
            String[] col1={"Employee name", "Work Duration"};
            DefaultTableModel model1= new DefaultTableModel(col1,0);

            List <Employee> employees=utility.filterEmployeesStatistics(tm);

            for(Employee e:employees)
            {
                Object[] row={e.getName(), tm.calculateEmployeeWorkDuration(e.getIdEmployee())};
                model1.addRow(row);
            }

            JTable tabel1= new JTable(model1);
            JScrollPane sp1 = new JScrollPane(tabel1);


            //Table for completed/uncompleted
            String[] col2={"Employee name", "Completed", "Uncompleted"};
            DefaultTableModel model2= new DefaultTableModel(col2,0);

            Map<String,Map<String, Integer>> statusMap=utility.computeTasksStatus(tm);
            for(String name: statusMap.keySet())
            {
                Map<String, Integer> tasks=statusMap.get(name);
                Object[] row={name, tasks.get("Completed"), tasks.get("Uncompleted") };
                model2.addRow(row);
            }

            JTable tabel2= new JTable(model2);
            JScrollPane sp2 = new JScrollPane(tabel2);

            tablesPanel.add(sp1);
            tablesPanel.add(sp2);
            frame.add(tablesPanel, BorderLayout.CENTER);
            frame.setVisible(true);

        }
}
