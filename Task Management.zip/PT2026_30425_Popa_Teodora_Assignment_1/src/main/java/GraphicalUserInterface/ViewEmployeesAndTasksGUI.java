package GraphicalUserInterface;

import BusinessLogic.TasksManagement;
import DataAccess.FileHandler;
import DataModel.Employee;

import javax.swing.*;
import java.awt.*;
import javax.swing.JFrame;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
import java.util.HashMap;

public class ViewEmployeesAndTasksGUI {

    public static void showTable(ArrayList<Employee> employees, TasksManagement tm, JFrame previousFrame)
    {

        JFrame frame = new JFrame("View Employees and Tasks");
        frame.setSize(500, 800);
        frame.setLocationRelativeTo(null);

        JButton backButton=new JButton("Back");
        backButton.setPreferredSize(new Dimension(80,25));
        backButton.addActionListener(e->{
            frame.dispose();
            previousFrame.setVisible(true);
        });
        JPanel topPanel=new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.add(backButton);
        frame.add(topPanel,BorderLayout.NORTH);

        String[] titles={"Employee Name", "Task ID", "Estimated Duration", "Status"};

        DefaultTableModel model= new DefaultTableModel(titles,0);
        for(Employee e: tm.getMap().keySet())
        {
            var tasks=tm.getMap().get(e);
            if(tasks!=null && !tasks.isEmpty())
            {
                for(var t:tasks)
                {
                    Object[] row={e.getName(),t.getIdTask(),t.estimateDuration(), t.getStatusTask()};
                    model.addRow(row);
                }
            }
            else{
                Object[] row={e.getName(),"-","-", "-"};
                model.addRow(row);
            }
        }

        JTable table= new JTable(model);
        JScrollPane scrollPane= new JScrollPane(table); //for scrolling down

        frame.add(scrollPane,BorderLayout.CENTER);


        frame.setVisible(true);
    }
}
