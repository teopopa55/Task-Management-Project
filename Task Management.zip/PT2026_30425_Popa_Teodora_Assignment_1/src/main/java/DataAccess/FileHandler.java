package DataAccess;

import BusinessLogic.TasksManagement;

import java.io.*;
import java.text.ParseException;

public class FileHandler
{

    public static void saveData(TasksManagement tm) throws
             ParseException, IOException, ClassNotFoundException
             {
                 FileOutputStream fileOutputStream = new FileOutputStream("info.txt");
                 ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
                 objectOutputStream.writeObject(tm);
                 //objectOutputStream.flush();
                 objectOutputStream.close();

             }

             public static TasksManagement loadData() throws Exception {
                 File file = new File("info.txt");
                 if (!file.exists()) return null; // Return null if no save file exists yet

                 try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
                     return (TasksManagement) ois.readObject();
                 }
             }

    }
